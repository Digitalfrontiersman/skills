# Security hardening

This public skill is a target for supply-chain tampering. Apply these controls
in the GitHub repository settings before accepting outside contributions:

1. Protect `main`: require pull requests, require one approval, require status
   checks, require conversation resolution, and block force pushes/deletions.
2. Require review from `CODEOWNERS` for changes to scanner rules, workflows,
   release safeguards, and skill instructions.
3. Keep GitHub Actions on least privilege. Do not add repository secrets to
   pull-request workflows or allow workflows from forks to write to the repo.
4. Enable Dependabot alerts and secret scanning. Review every alert; do not
   auto-merge security changes blindly.
5. Publish tagged releases with a SHA-256 checksum for any ZIP release. Users
   should verify checksums before use.

These controls reduce risk; they do not make a public project unhackable.
Treat all issues, pull requests, dependencies, instructions, and uploaded
files as untrusted until reviewed.
