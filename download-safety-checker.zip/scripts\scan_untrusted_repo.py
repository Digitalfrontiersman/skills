#!/usr/bin/env python3
"""Static triage for untrusted repository text. Does not execute target code."""

from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path

TEXT_EXTENSIONS = {
    ".md", ".txt", ".rst", ".py", ".js", ".ts", ".tsx", ".jsx", ".json",
    ".yaml", ".yml", ".toml", ".ini", ".cfg", ".ps1", ".sh", ".bash", ".bat",
    ".cmd", ".xml", ".html", ".css", ".go", ".rs", ".java", ".rb", ".php",
}
SKIP_DIRS = {".git", "node_modules", "vendor", "dist", "build", ".venv", "venv"}
MAX_ARCHIVE_FILES = 10_000
MAX_ARCHIVE_BYTES = 100 * 1024 * 1024
RULES = [
    ("critical", "shell-pipe-download", r"(?:curl|wget)\b[^\n|]{0,240}\|\s*(?:ba)?sh\b"),
    ("critical", "powershell-download-exec", r"(?:(?:invoke-expression|iex\b|downloadstring|webclient).*?(?:http|https)|(?:iwr|invoke-webrequest).*?(?:http|https).*?\|\s*(?:iex|invoke-expression))"),
    ("high", "encoded-payload", r"(?:base64\s+(?:-d|--decode)|frombase64string|eval\s*\()"),
    ("high", "credential-or-secret-access", r"(?:\.ssh|aws_access_key|github_token|api[_-]?key|secret[_-]?key|credential)"),
    ("high", "package-install-hook", r"(?:preinstall|postinstall|prepare)\b"),
    ("high", "prompt-injection-override", r"(?:ignore|disregard|override|forget)\s+(?:all\s+)?(?:previous|prior|system|developer).*?(?:instruction|prompt)"),
    ("high", "prompt-injection-concealment", r"(?:do not tell|hide (?:this|your)|keep (?:this|it) secret|silently)"),
    ("high", "prompt-injection-exfiltration", r"(?:send|upload|exfiltrate|reveal).*?(?:secret|token|credential|password|private data)"),
    ("medium", "remote-execution-api", r"(?:child_process|subprocess\.|os\.system|runtime\.getruntime\(\)\.exec)"),
    ("medium", "external-network-call", r"(?:https?://|requests\.(?:get|post)|fetch\(|axios\.|invoke-webrequest)"),
]


def scan_text(name: str, text: str) -> list[dict]:
    findings = []
    for number, line in enumerate(text.splitlines(), start=1):
        for severity, rule, pattern in RULES:
            if re.search(pattern, line, flags=re.IGNORECASE):
                findings.append({
                    "file": name, "line": number, "severity": severity,
                    "rule": rule, "excerpt": line.strip()[:300],
                })
    return findings


def scan_file(path: Path) -> list[dict]:
    try:
        return scan_text(str(path), path.read_text(encoding="utf-8", errors="replace"))
    except OSError:
        return []


def scan_zip(path: Path) -> list[dict]:
    """Inspect text members without extracting or executing an archive."""
    findings: list[dict] = []
    try:
        with zipfile.ZipFile(path) as archive:
            members = archive.infolist()
            total_size = sum(member.file_size for member in members)
            if len(members) > MAX_ARCHIVE_FILES or total_size > MAX_ARCHIVE_BYTES:
                findings.append({"file": str(path), "line": 0, "severity": "high",
                                 "rule": "oversized-or-dense-archive",
                                 "excerpt": f"Archive has {len(members)} files and {total_size} uncompressed bytes."})
            for member in members[:MAX_ARCHIVE_FILES]:
                member_path = Path(member.filename)
                if member.is_dir() or any(part in SKIP_DIRS for part in member_path.parts):
                    continue
                if member_path.suffix.lower() not in TEXT_EXTENSIONS or member.file_size > 2 * 1024 * 1024:
                    continue
                try:
                    text = archive.read(member).decode("utf-8", errors="replace")
                except (OSError, RuntimeError, zipfile.BadZipFile):
                    continue
                findings.extend(scan_text(f"{path}!{member.filename}", text))
    except (OSError, zipfile.BadZipFile):
        findings.append({"file": str(path), "line": 0, "severity": "high",
                         "rule": "unreadable-archive", "excerpt": "Could not safely read this ZIP archive."})
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description="Statically triage an untrusted repository without executing it.")
    parser.add_argument("path", type=Path, help="Local code folder or ZIP archive")
    parser.add_argument("--json", action="store_true", help="Emit JSON")
    args = parser.parse_args()
    root = args.path.resolve()
    findings = []
    if root.is_file() and root.suffix.lower() == ".zip":
        findings = scan_zip(root)
    elif root.is_dir():
        for path in root.rglob("*"):
            if any(part in SKIP_DIRS for part in path.parts) or not path.is_file() or path.suffix.lower() not in TEXT_EXTENSIONS:
                continue
            findings.extend(scan_file(path))
    else:
        parser.error("path must be a directory or ZIP archive")
    rank = {"critical": 0, "high": 1, "medium": 2}
    findings.sort(key=lambda item: (rank[item["severity"]], item["file"], item["line"]))
    summary = {level: sum(item["severity"] == level for item in findings) for level in rank}
    result = {"root": str(root), "summary": summary, "findings": findings}
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"Scanned: {root}")
        print("Findings: " + ", ".join(f"{k}={v}" for k, v in summary.items()))
        for item in findings:
            print(f"[{item['severity'].upper()}] {item['rule']} {item['file']}:{item['line']}\n  {item['excerpt']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
